\ TritiumOS core bootstrap — Creator: Draco
\ DuskOS/CollapseOS-inspired minimal Forth base for TritiumForth.
." TritiumOS core" cr
include trit.fs
include tritium-kernel.fs
include drena.fs
include rekia.fs
include queue.fs
include assimilate.fs
include lineos.fs
include integrate.fs
include master.fs
include fleet.fs
." boot ok — run rekia-demo for smoke" cr
